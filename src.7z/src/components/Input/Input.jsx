import styled from 'styled-components';

const Input = styled.input`

    

`

export default Input;