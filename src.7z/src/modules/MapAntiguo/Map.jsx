// import { React, useEffect, useRef } from 'react'
// import Div from '../../components/Div/Div'


// function Map({ center, zoom }) {

//     const ref = useRef();

//     useEffect(() => {
//         new window.google.maps.Map(ref.current, {
//             center,
//             zoom,
//         });
//     });
    
//     return (
//         <Div ref={ref} className='contact-map' />
//     )

// }

// export default Map;