export const googleMapKey = 'AIzaSyAOt5PzBT0dGqDoEJ9iLQ9Gqqr1PoP6Xqk'

export const serverApis = ["http://localhost:3001"]
// export const serverApis = ['/']